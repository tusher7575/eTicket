/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myproject.eticket.repository;

import com.myproject.eticket.model.Bustimetable;
import com.myproject.eticket.service.BustimetableService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author User
 */
@Repository
public class BustimetableRepository implements BustimetableService{

    @Autowired
    SessionFactory sessionFactory;
    @Override
    public Bustimetable insertBustimetable(Bustimetable bt) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(bt);
        t.commit();
        s.close();
        return bt;
    }

    @Override
    public void updateBustimetable(Bustimetable bt) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(bt);
        t.commit();
        s.close();
    }

    @Override
    public void deleteBustimetable(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Bustimetable bt = (Bustimetable) s.get(Bustimetable.class, id);
        s.delete(bt);
        t.commit();
        s.close();
    }

    @Override
    public List<Bustimetable> viewBustimetable() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Bustimetable> bustimetablelist = s.createQuery("from Bustimetable").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return bustimetablelist;
    }

    @Override
    public Bustimetable viewOneBustimetable(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Bustimetable bt = (Bustimetable) s.get(Bustimetable.class, id);
        t.commit();
        s.close();
        return bt;
    }

   
    
}
